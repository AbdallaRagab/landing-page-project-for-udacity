# Landing Page Project

## Table of Contents

* [Description](#Description)
* [Title](#Title)

## Title

Landing page project for Udacity

## Description

This is a simple landing page of 4 sections with fixed navigation menu.

The navigation menu was created dynamically using JavaScript.

Clicking any section of the navigation menu will scroll automatically to that section of the page.

Scrolling to a specific section will change the style of it to give the user a clear idea of the current section of the page that they are cu seeing.