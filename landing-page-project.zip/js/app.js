/**
 * 
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 * 
 * Dependencies: None
 * 
 * JS Version: ES2015/ES6
 * 
 * JS Standard: ESlint
 * 
*/

/**
 * Comments should be present at the beginning of each procedure and class.
 * Great to have comments before crucial code sections within the procedure.
*/

/**
 * Define Global Variables
 * 
*/

let nav = document.querySelector('#navbar__list')
let sections = document.querySelectorAll('section')
let navItems = nav.children
// let navItem = document.createElement('li')

/**
 * End Global Variables
 * Start Helper Functions
 * 
*/
const RemoveActiveClass = function () {
    for (const section of sections){
        section.classList.remove('active-section')
    }
    for (const item of nav.children){
        item.classList.remove('active-nav-item')
    }
}
const AddActiveClass = function (id) {
    let section = document.getElementById(id)
    section.classList.add('active-section')
    let item = document.querySelector(`[section-id = "${id}"]`).parentElement
    item.classList.add('active-nav-item')
}

/**
 * End Helper Functions
 * Begin Main Functions
 * 
*/

// build the nav

sections.forEach(function (section) {
    var navItem = document.createElement('li')
    var sectionId = section.id
    var sectionTite = section.children[0].children[0].innerText
    nav.appendChild(navItem)
    navItem.innerHTML = `<a href="#" class="nav-link" section-id="${sectionId}">${sectionTite}</a>`
})

// Add class 'active' to section when near top of viewport

const onScroll = function () {
    var scrollYPosition = document.body.scrollTop + (0.5 * window.innerHeight )
    sections.forEach(function(section) {
        var sectionId = section.id
        var sectionTite = section.children[0].children[0].innerText
        if (scrollYPosition >= section.offsetTop
            && scrollYPosition < section.offsetTop + section.offsetHeight ){
                RemoveActiveClass()
                AddActiveClass(sectionId)
        }
    })
}

document.addEventListener('scroll', onScroll)
// Scroll to anchor ID using scrollTO event

for (const item of nav.children){
    let link = item.children[0]
    let sectionId = link.getAttribute('section-id')
    let section = document.getElementById(sectionId)
    let scrollToPoint
    item.onclick = function(event)
    {
        if( section.offsetHeight > window.innerHeight ){ scrollToPoint = section.offsetTop }
        else{ scrollToPoint = section.offsetTop -  (window.innerHeight - section.offsetHeight) / 2 }
        event.preventDefault();
        window.scrollTo({
            top: scrollToPoint ,
            behavior: "smooth"
       });
    }
}

/**
 * End Main Code
 * 
*/
